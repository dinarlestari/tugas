<?php 
mysql_connect("localhost","root","");
mysql_select_db("penjualan");
?>