<?php 
include 'config.php';
$supplier=$_POST['supplier'];
$nama=$_POST['nama'];
$hb=$_POST['harga_beli'];

mysql_query("insert into pembelian values('','$supplier','$nama','$hb')");
header("location:pembelian.php");

 ?>