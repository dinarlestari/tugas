<?php 
include 'config.php';
$id=$_POST['id'];
$tgl=$_POST['tanggal'];
$nama=$_POST['nama'];
$harga=$_POST['harga'];
$jumlah=$_POST['jumlah'];

$dt=mysql_query("select * from barang where nama='$nama'");
$data=mysql_fetch_array($dt);
$sisa=$data['jumlah']-$jumlah;
mysql_query("update barang set jumlah='$sisa' where nama='$nama'");

$modal=$data['modal'];
$laba=$harga-$modal;
$labaa=$laba*$jumlah;
$total_harga=$harga*$jumlah;
mysql_query("update barang_laku set tgl='$tgl', nama='$nama', harga='$harga', jumlah='$jumlah', total_harga='$total_harga', laba='$labaa' where id='$id'");
header("location:barang_laku.php");

?>