<?php include 'header.php'; ?>

<h3><span class="glyphicon glyphicon-briefcase"></span>  Database</h3>
<br/>
<h4>Trigger</h4>
<table class="table table-hover">
	<tr>
		<th class="col-md-1">No</th>
		<th class="col-md-1">Nama Barang lama</th>
		<th class="col-md-1">Harga Barang Baru</th>
		<th class="col-md-1">Harga Lama</th>
        <th class="col-md-1">Harga Baru</th>
        <th class="col-md-1">Tanggal</th>
	</tr>
	<?php 
	if(isset($_GET['cari'])){
		$cari=mysql_real_escape_string($_GET['cari']);
		$brg=mysql_query("select * from log_harga_barang where id");
	}else{
		$brg=mysql_query("select * from log_harga_barang");
	}
	$no=1;
	while($b=mysql_fetch_array($brg)){

		?>
		<tr>
			<td><?php echo $no++ ?></td>
			<td><?php echo $b['nama_barang_lama'] ?></td>
            <td><?php echo $b['nama_barang_baru'] ?></td>
			<td>Rp.<?php echo number_format($b['harga_lama']) ?>,-</td>
            <td>Rp.<?php echo number_format($b['harga_baru']) ?>,-</td>
            <td><?php echo $b['tanggal'] ?></td>
		</tr>		
		<?php 
	}
	?>
	
</table>

<h4>view</h4>
<table class="table table-hover">
	<tr>
		<th class="col-md-1">No</th>
		<th class="col-md-1">Nama Barang</th>
		<th class="col-md-1">Modal</th>
		<th class="col-md-1">Laba</th>
	</tr>
	<?php 
	if(isset($_GET['cari'])){
		$cari=mysql_real_escape_string($_GET['cari']);
		$brg=mysql_query("select * from v_barang where nama");
	}else{
		$brg=mysql_query("select * from v_barang");
	}
	$no=1;
	while($b=mysql_fetch_array($brg)){

		?>
		<tr>
			<td><?php echo $no++ ?></td>
			<td><?php echo $b['nama'] ?></td>
			<td>Rp.<?php echo number_format($b['modal']) ?>,-</td>
            <td>Rp.<?php echo number_format($b['laba']) ?>,-</td>

		</tr>		
		<?php 
	}
	?>
	
</table>

<?php 
include 'footer.php';

?>