-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 24 Jul 2018 pada 08.27
-- Versi Server: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `penjualan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
`id` int(11) NOT NULL,
  `uname` varchar(30) NOT NULL,
  `pass` varchar(70) NOT NULL,
  `foto` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `uname`, `pass`, `foto`) VALUES
(8, 'admin', '21232f297a57a5a743894a0e4a801fc3', '_bts__draw_bt21_by_konayuki_187-dc5astg.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE IF NOT EXISTS `barang` (
`id` int(11) NOT NULL,
  `id_supplier` int(11) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `jenis` varchar(25) NOT NULL,
  `modal` varchar(30) NOT NULL,
  `harga` varchar(30) NOT NULL,
  `jumlah` varchar(20) NOT NULL,
  `sisa` varchar(15) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`id`, `id_supplier`, `nama`, `jenis`, `modal`, `harga`, `jumlah`, `sisa`) VALUES
(1, 1, 'Buku tulis', 'ATK', '50000', '55000', '20', '30'),
(2, 5, 'tim tam', 'makanan', '2000', '3000', '790', '792'),
(3, 1, 'Buku gambar', 'ATK', '10000', '12000', '40', '50'),
(4, 2, 'tic tac', 'makanan', '2000', '4000', '10', '10'),
(5, 3, 'pensil', 'ATK', '2000', '3000', '190', '200'),
(6, 4, 'Bimoli', 'Minyak Goreng', '25000', '27000', '100', '100'),
(7, 5, 'Kotak pensil', 'ATK', '10000', '15000', '300', '300'),
(8, 2, 'Sunco', 'Minyak Goreng', '25000', '26000', '200', '200'),
(9, 1, 'Kacang Atom Garuda', 'makanan', '5000', '8000', '200', '200'),
(10, 3, 'Pilus', 'makanan', '3000', '4000', '100', '100'),
(11, 2, 'Kacang telur', 'makanan', '3000', '4000', '100', '100'),
(12, 1, 'telur', 'bahan masakan', '9000', '10000', '25', '30'),
(13, 1, 'kopi', 'minuman', '1000', '2000', '10', '10');

--
-- Trigger `barang`
--
DELIMITER //
CREATE TRIGGER `updt_harga` AFTER UPDATE ON `barang`
 FOR EACH ROW begin
insert into log_harga_barang(id_log, id, nama_barang_lama, nama_barang_baru, harga_lama, harga_baru, tanggal)
values('i', old.id, old.nama, new.nama, old.harga, new.harga, now());
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang_laku`
--

CREATE TABLE IF NOT EXISTS `barang_laku` (
`id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jumlah` varchar(20) NOT NULL,
  `harga` varchar(20) NOT NULL,
  `total_harga` varchar(20) NOT NULL,
  `laba` varchar(20) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data untuk tabel `barang_laku`
--

INSERT INTO `barang_laku` (`id`, `tanggal`, `nama`, `jumlah`, `harga`, `total_harga`, `laba`) VALUES
(1, '2018-07-21', 'Buku tulis', '10', '55000', '550000', '50000'),
(2, '2018-07-20', 'tim tam', '2', '4000', '8000', '4000'),
(5, '2018-07-22', 'tic tac', '3', '6000', '10000', '0'),
(6, '2018-07-22', 'Buku gambar', '10', '12000', '120000', '20000'),
(7, '2018-07-21', 'pensil', '10', '3000', '30000', '10000'),
(8, '2018-07-22', 'telur', '5', '10000', '50000', '5000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `log_harga_barang`
--

CREATE TABLE IF NOT EXISTS `log_harga_barang` (
`id_log` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `nama_barang_lama` varchar(30) NOT NULL,
  `nama_barang_baru` varchar(30) NOT NULL,
  `harga_lama` varchar(20) NOT NULL,
  `harga_baru` varchar(20) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data untuk tabel `log_harga_barang`
--

INSERT INTO `log_harga_barang` (`id_log`, `id`, `nama_barang_lama`, `nama_barang_baru`, `harga_lama`, `harga_baru`, `tanggal`) VALUES
(1, 1, 'Buku tulis', 'Buku tulis', '15000', '16000', '2018-07-23'),
(2, 1, 'Buku tulis', 'Buku tulis', '16000', '17000', '2018-07-23'),
(3, 1, 'Buku tulis', 'Buku tulis', '17000', '55000', '2018-07-23'),
(5, 4, 'tic tac', 'tic tac', '4000', '4000', '2018-07-24'),
(6, 2, 'tim tam', 'tim tam', '6000', '7000', '2018-07-24'),
(7, 2, 'tim tam', 'tim tam', '7000', '3000', '2018-07-24');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembelian`
--

CREATE TABLE IF NOT EXISTS `pembelian` (
`id_pembelian` int(11) NOT NULL,
  `id_supplier` int(11) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `harga_beli` varchar(20) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data untuk tabel `pembelian`
--

INSERT INTO `pembelian` (`id_pembelian`, `id_supplier`, `nama`, `harga_beli`) VALUES
(1, 1, 'Buku tulis', '50000'),
(2, 5, 'tim tam', '2000'),
(3, 1, 'Buku gambar', '10000'),
(4, 2, 'tic tac', '2000'),
(5, 3, 'pensil', '2000'),
(6, 4, 'Bimoli', '25000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `supplier`
--

CREATE TABLE IF NOT EXISTS `supplier` (
`id_supplier` int(11) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `alamat` varchar(30) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data untuk tabel `supplier`
--

INSERT INTO `supplier` (`id_supplier`, `nama`, `alamat`) VALUES
(1, 'PT. Sampurna', 'Kebonsari'),
(2, 'PT. Maju Jaya', 'Jember'),
(3, 'PT. Sinar', 'Ambulu'),
(4, 'PT. Jaya Abadi', 'Jember'),
(5, 'PT. Sinar Maju', 'Pakusari');

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_barang`
--
CREATE TABLE IF NOT EXISTS `v_barang` (
`nama` varchar(25)
,`modal` varchar(30)
,`laba` varchar(20)
);
-- --------------------------------------------------------

--
-- Struktur untuk view `v_barang`
--
DROP TABLE IF EXISTS `v_barang`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_barang` AS select `barang`.`nama` AS `nama`,`barang`.`modal` AS `modal`,`barang_laku`.`laba` AS `laba` from (`barang` join `barang_laku`) where (`barang`.`nama` = `barang_laku`.`nama`);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `barang_laku`
--
ALTER TABLE `barang_laku`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log_harga_barang`
--
ALTER TABLE `log_harga_barang`
 ADD PRIMARY KEY (`id_log`);

--
-- Indexes for table `pembelian`
--
ALTER TABLE `pembelian`
 ADD PRIMARY KEY (`id_pembelian`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
 ADD PRIMARY KEY (`id_supplier`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `barang_laku`
--
ALTER TABLE `barang_laku`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `log_harga_barang`
--
ALTER TABLE `log_harga_barang`
MODIFY `id_log` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `pembelian`
--
ALTER TABLE `pembelian`
MODIFY `id_pembelian` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
MODIFY `id_supplier` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
